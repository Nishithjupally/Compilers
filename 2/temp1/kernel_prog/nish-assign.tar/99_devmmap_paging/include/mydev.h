/*
 *
 * Copyright (C) 1998-2020 Maruthi Seshidhar Inukonda - All Rights Reserved.
 * maruthi.inukonda@gmail.com
 *
 * This file is released under the GPL v2.
 *
 * This file may be redistributed under the terms of the GNU Public License.
 *
 */

#ifndef __MYDEV__
#define MYDEV_LEN (1024 * 1024) // 1MB
#endif

